Curso de Especialização de Inteligência Artificial Aplicada

Setor de Educação Profissional e Tecnológica - SEPT

Universidade Federal do Paraná - UFPR

---

**IAA003 - Linguagem de Programação Aplicada**

Prof. Alexander Robert Kutzke

# Movielens dataset

Exemplo de análise do dataset da Movielens com Pandas.

[Mais informações sobre o dataset](datasets/movielens/README).
